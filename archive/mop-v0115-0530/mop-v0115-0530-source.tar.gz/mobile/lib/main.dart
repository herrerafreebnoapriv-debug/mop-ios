import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'app.dart';
import 'core/config/app_config.dart';
import 'core/services/storage_service.dart';
import 'core/services/network_service.dart';
import 'core/services/endpoint_manager.dart';
import 'locales/app_localizations.dart';
import 'providers/auth_provider.dart';
import 'providers/language_provider.dart';
import 'providers/socket_provider.dart';
import 'screens/auth/login_screen.dart';
import 'screens/auth/register_screen.dart';
import 'screens/home/home_screen.dart';
import 'screens/qr/scan_screen.dart';
import 'screens/room/room_screen.dart';
import 'screens/settings/settings_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // 初始化本地存储
  final prefs = await SharedPreferences.getInstance();
  StorageService.instance.init(prefs);
  
  // 初始化网络监听服务
  NetworkService.instance.init();
  
  // 初始化端点管理器
  await EndpointManager.instance.init();
  
  // 加载应用配置
  await AppConfig.instance.loadConfig();
  
  runApp(const MOPApp());
}

class MOPApp extends StatelessWidget {
  const MOPApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => LanguageProvider()),
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => SocketProvider()),
      ],
      child: Consumer<LanguageProvider>(
        builder: (context, languageProvider, _) {
          return MaterialApp(
            title: '和平信使',
            debugShowCheckedModeBanner: false,
            
            // 国际化配置
            locale: languageProvider.currentLocale,
            supportedLocales: const [
              Locale('zh', 'CN'),  // 简体中文
              Locale('zh', 'TW'),  // 繁体中文
              Locale('en', 'US'),  // 英文
              Locale('ja', 'JP'),  // 日文
              Locale('ko', 'KR'),  // 韩文
            ],
            localizationsDelegates: const [
              AppLocalizations.delegate,
              GlobalMaterialLocalizations.delegate,
              GlobalWidgetsLocalizations.delegate,
              GlobalCupertinoLocalizations.delegate,
            ],
            
            // 主题配置
            theme: ThemeData(
              primarySwatch: Colors.blue,
              primaryColor: const Color(0xFF667eea),
              useMaterial3: true,
              colorScheme: ColorScheme.fromSeed(
                seedColor: const Color(0xFF667eea),
              ),
            ),
            
            // 路由配置
            initialRoute: '/',
            routes: {
              '/': (context) => const AppMain(),
              '/scan': (context) => const ScanScreen(),
              '/register': (context) => const RegisterScreen(),
              '/home': (context) => const HomeScreen(),
              '/room': (context) {
                final args = ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>;
                return RoomScreen(
                  roomId: args['roomId'] as String,
                  roomName: args['roomName'] as String?,
                );
              },
              '/settings': (context) => const SettingsScreen(),
            },
          );
        },
      ),
    );
  }
}
