import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:convert';

/// 应用国际化
class AppLocalizations {
  final Locale locale;
  
  AppLocalizations(this.locale);
  
  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }
  
  static const LocalizationsDelegate<AppLocalizations> delegate = _AppLocalizationsDelegate();
  
  Map<String, String>? _localizedStrings;
  
  Future<bool> load() async {
    final jsonString = await rootBundle.loadString('assets/locales/${locale.languageCode}_${locale.countryCode}.json');
    final jsonMap = json.decode(jsonString) as Map<String, dynamic>;
    
    _localizedStrings = jsonMap.map((key, value) => MapEntry(key, value.toString()));
    return true;
  }
  
  String translate(String key) {
    return _localizedStrings?[key] ?? key;
  }
  
  String t(String key) => translate(key);
}

class _AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();
  
  @override
  bool isSupported(Locale locale) {
    return ['zh', 'en', 'ja', 'ko'].contains(locale.languageCode);
  }
  
  @override
  Future<AppLocalizations> load(Locale locale) async {
    final localizations = AppLocalizations(locale);
    await localizations.load();
    return localizations;
  }
  
  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}
