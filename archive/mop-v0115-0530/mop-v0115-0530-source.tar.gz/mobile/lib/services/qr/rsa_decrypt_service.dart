import 'dart:convert';
import 'dart:typed_data';
import 'package:pointycastle/export.dart';
import 'package:crypto/crypto.dart';

/// RSA 解密服务
/// 用于解密从二维码扫描获取的加密数据
class RSADecryptService {
  /// 从 PEM 格式的公钥字符串加载公钥
  static RSAPublicKey _parsePublicKeyFromPem(String pemString) {
    // 移除 PEM 格式的头部和尾部
    final publicKeyDER = _removePemHeaders(pemString);
    
    // Base64 解码
    final publicKeyBytes = base64Decode(publicKeyDER);
    
    // 使用 ASN1Parser 解析 DER 格式的公钥
    final asn1Parser = ASN1Parser(publicKeyBytes);
    final topLevelSeq = asn1Parser.nextObject() as ASN1Sequence;
    
    // RSA 公钥的 ASN1 结构：
    // RSAPublicKey ::= SEQUENCE {
    //   modulus           INTEGER,  -- n
    //   publicExponent    INTEGER   -- e
    // }
    final modulus = (topLevelSeq.elements![0] as ASN1Integer).intValue;
    final exponent = (topLevelSeq.elements![1] as ASN1Integer).intValue;
    
    return RSAPublicKey(modulus!, exponent!);
  }
  
  /// 移除 PEM 格式的头部和尾部
  static String _removePemHeaders(String pemString) {
    return pemString
        .replaceAll('-----BEGIN PUBLIC KEY-----', '')
        .replaceAll('-----END PUBLIC KEY-----', '')
        .replaceAll('-----BEGIN RSA PUBLIC KEY-----', '')
        .replaceAll('-----END RSA PUBLIC KEY-----', '')
        .replaceAll('\n', '')
        .replaceAll('\r', '')
        .replaceAll(' ', '');
  }
  
  /// 使用 RSA 公钥解密数据
  /// 
  /// [encryptedData] Base64 编码的加密数据
  /// [publicKeyPem] PEM 格式的 RSA 公钥
  /// 
  /// 返回解密后的 JSON 字符串
  static String decrypt(String encryptedData, String publicKeyPem) {
    try {
      // Base64 解码加密数据
      final encryptedBytes = base64Decode(encryptedData);
      
      // 解析公钥
      final publicKey = _parsePublicKeyFromPem(publicKeyPem);
      
      // 创建 RSA 加密器（用于解密，因为使用公钥解密）
      final cipher = OAEPEncoding(RSAEngine())
        ..init(false, PublicKeyParameter<RSAPublicKey>(publicKey));
      
      // RSA 解密（实际是使用公钥验证签名，这里用于解密）
      // 注意：标准 RSA 加密使用公钥加密、私钥解密
      // 但这里可能是 RSA 签名验证的场景，需要根据实际后端实现调整
      
      // 如果后端使用的是私钥加密、公钥解密（签名场景）
      // 这里使用公钥解密
      final decryptedBytes = cipher.process(encryptedBytes);
      
      // 转换为字符串
      final decryptedString = utf8.decode(decryptedBytes);
      
      return decryptedString;
    } catch (e) {
      throw Exception('RSA 解密失败: $e');
    }
  }
  
  /// 验证并解析二维码数据
  /// 
  /// 支持两种格式：
  /// 1. 加密二维码：RSA 加密的 Base64 数据
  /// 2. 未加密二维码：JSON 字符串或 URL
  /// 
  /// 返回解析后的数据字典
  static Map<String, dynamic> parseQRCodeData(
    String qrData, {
    String? publicKeyPem,
  }) {
    try {
      // 尝试作为 URL 解析
      if (qrData.startsWith('http://') || qrData.startsWith('https://')) {
        return _parseUrlFormat(qrData);
      }
      
      // 尝试作为 JSON 解析（未加密）
      try {
        final jsonData = jsonDecode(qrData) as Map<String, dynamic>;
        if (jsonData.containsKey('room_id') || jsonData.containsKey('api_url')) {
          return jsonData;
        }
      } catch (e) {
        // 不是 JSON 格式，继续尝试解密
      }
      
      // 尝试 RSA 解密（加密二维码）
      if (publicKeyPem != null && publicKeyPem.isNotEmpty) {
        try {
          final decryptedData = decrypt(qrData, publicKeyPem);
          final jsonData = jsonDecode(decryptedData) as Map<String, dynamic>;
          return jsonData;
        } catch (e) {
          throw Exception('RSA 解密失败: $e');
        }
      } else {
        throw Exception('未提供 RSA 公钥，无法解密加密二维码');
      }
    } catch (e) {
      throw Exception('二维码数据解析失败: $e');
    }
  }
  
  /// 解析 URL 格式的二维码数据
  /// 格式：https://domain.com/room/{room_id}?token=xxx
  static Map<String, dynamic> _parseUrlFormat(String url) {
    final uri = Uri.parse(url);
    final pathParts = uri.path.split('/');
    
    final data = <String, dynamic>{};
    
    // 提取房间ID
    if (pathParts.length >= 2 && pathParts[pathParts.length - 2] == 'room') {
      data['room_id'] = pathParts[pathParts.length - 1];
    }
    
    // 提取查询参数
    uri.queryParameters.forEach((key, value) {
      data[key] = value;
    });
    
    // 如果 URL 包含域名，可以提取 API URL
    if (uri.host.isNotEmpty) {
      data['api_url'] = '${uri.scheme}://${uri.host}${uri.port != 80 && uri.port != 443 ? ':${uri.port}' : ''}/api/v1';
    }
    
    return data;
  }
}
