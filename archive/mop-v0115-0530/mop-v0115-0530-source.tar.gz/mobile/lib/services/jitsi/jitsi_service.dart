import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:jitsi_meet/jitsi_meet.dart';

import '../../core/config/app_config.dart';
import '../../services/api/api_service.dart';

/// Jitsi Meet 服务
/// 管理视频通话功能
class JitsiService {
  static final JitsiService instance = JitsiService._internal();
  JitsiService._internal();
  
  final ApiService _apiService = ApiService();
  
  /// 加入房间
  /// 
  /// [roomId] 房间ID
  /// [userName] 用户显示名称
  /// [userEmail] 用户邮箱（可选）
  /// [isAudioMuted] 是否静音
  /// [isVideoMuted] 是否关闭视频
  Future<void> joinRoom({
    required String roomId,
    required String userName,
    String? userEmail,
    bool isAudioMuted = false,
    bool isVideoMuted = false,
  }) async {
    try {
      // 获取 Jitsi 服务器地址
      final jitsiServerUrl = AppConfig.instance.jitsiServerUrl;
      if (jitsiServerUrl == null || jitsiServerUrl.isEmpty) {
        throw Exception('Jitsi 服务器地址未配置');
      }
      
      // 获取 JWT Token（如果需要）
      String? jwtToken;
      try {
        final tokenResponse = await _apiService.post('/rooms/$roomId/jitsi-token');
        if (tokenResponse != null && tokenResponse['jwt_token'] != null) {
          jwtToken = tokenResponse['jwt_token'] as String;
        }
      } catch (e) {
        // JWT Token 获取失败，可能不需要认证
        debugPrint('获取 JWT Token 失败: $e');
      }
      
      // 配置 Jitsi Meet 选项
      final options = JitsiMeetingOptions(
        room: roomId,
        serverURL: jitsiServerUrl,
        userDisplayName: userName,
        userEmail: userEmail,
        audioMuted: isAudioMuted,
        videoMuted: isVideoMuted,
        token: jwtToken,
        
        // 功能配置
        featureFlags: {
          'welcomepage.enabled': false,
          'invite.enabled': false,
          'calendar.enabled': false,
          'call-integration.enabled': false,
          'live-streaming.enabled': false,
          'recording.enabled': false,
          'transcription.enabled': false,
          'pip.enabled': true,
        },
        
        // 配置覆盖
        configOverrides: {
          'startWithAudioMuted': isAudioMuted,
          'startWithVideoMuted': isVideoMuted,
          'disableInviteFunctions': true,
          'disableThirdPartyRequests': true,
          'enableCalendarIntegration': false,
          'mobileAppPromo': false,
        },
      );
  
      // 加入会议
      await JitsiMeet.joinMeeting(
        options,
        listener: JitsiMeetingListener(
          onConferenceWillJoin: (message) {
            debugPrint('即将加入会议: $message');
          },
          onConferenceJoined: (message) {
            debugPrint('已加入会议: $message');
          },
          onConferenceTerminated: (message) {
            debugPrint('会议已结束: $message');
          },
          onError: (error) {
            debugPrint('会议错误: $error');
          },
        ),
      );
    } catch (e) {
      throw Exception('加入房间失败: $e');
    }
  }
  
  /// 离开房间
  Future<void> leaveRoom() async {
    try {
      await JitsiMeet.closeMeeting();
    } catch (e) {
      debugPrint('离开房间失败: $e');
    }
  }
  
  /// 开启/关闭音频
  Future<void> toggleAudio() async {
    // Jitsi Meet SDK 会自动处理
    // 如果需要手动控制，可以使用 MethodChannel
  }
  
  /// 开启/关闭视频
  Future<void> toggleVideo() async {
    // Jitsi Meet SDK 会自动处理
    // 如果需要手动控制，可以使用 MethodChannel
  }
  
  /// 开启/关闭屏幕共享
  Future<void> toggleScreenSharing() async {
    // 屏幕共享需要原生代码支持
    // Android: MediaProjection
    // iOS: ReplayKit
  }
}
