import 'package:shared_preferences/shared_preferences.dart';
import '../services/endpoint_manager.dart';

/// 应用配置管理
/// 管理动态获取的 API 地址、Jitsi 服务器地址等配置
/// 支持多端点管理和自动故障转移
class AppConfig {
  static final AppConfig instance = AppConfig._internal();
  
  AppConfig._internal();
  
  static const String _keyApiBaseUrl = 'api_base_url';
  static const String _keyJitsiServerUrl = 'jitsi_server_url';
  static const String _keySocketIoUrl = 'socketio_url';
  static const String _keyRoomId = 'current_room_id';
  
  String? _apiBaseUrl;
  String? _jitsiServerUrl;
  String? _socketIoUrl;
  String? _roomId;
  
  /// API 基础地址（从 EndpointManager 获取，支持多端点）
  String? get apiBaseUrl {
    // 优先从 EndpointManager 获取
    final endpointUrl = EndpointManager.instance.getCurrentApiUrl();
    if (endpointUrl != null) {
      return endpointUrl;
    }
    // 回退到旧配置
    return _apiBaseUrl;
  }
  
  /// Jitsi 服务器地址
  String? get jitsiServerUrl => _jitsiServerUrl;
  
  /// Socket.io 服务器地址（从 EndpointManager 获取，支持多端点）
  String? get socketIoUrl {
    // 优先从 EndpointManager 获取
    final endpointUrl = EndpointManager.instance.getCurrentSocketUrl();
    if (endpointUrl != null) {
      return endpointUrl;
    }
    // 回退到旧配置
    return _socketIoUrl;
  }
  
  /// 当前房间ID
  String? get roomId => _roomId;
  
  /// 是否已配置 API 地址
  bool get isConfigured {
    final endpointUrl = EndpointManager.instance.getCurrentApiUrl();
    return (endpointUrl != null && endpointUrl.isNotEmpty) ||
           (_apiBaseUrl != null && _apiBaseUrl!.isNotEmpty);
  }
  
  /// 加载配置（从本地存储）
  Future<void> loadConfig() async {
    final prefs = await SharedPreferences.getInstance();
    
    _apiBaseUrl = prefs.getString(_keyApiBaseUrl);
    _jitsiServerUrl = prefs.getString(_keyJitsiServerUrl);
    _socketIoUrl = prefs.getString(_keySocketIoUrl);
    _roomId = prefs.getString(_keyRoomId);
  }
  
  /// 更新配置（扫码后调用）
  /// [data] 是从二维码解析出来的配置数据
  Future<void> updateConfig(Map<String, dynamic> data) async {
    final prefs = await SharedPreferences.getInstance();
    
    // 更新端点管理器
    await EndpointManager.instance.updateEndpointsFromQRCode(data);
    
    // 兼容旧格式：单个 URL
    if (data.containsKey('api_url')) {
      _apiBaseUrl = data['api_url'] as String;
      await prefs.setString(_keyApiBaseUrl, _apiBaseUrl!);
      // 同时添加到端点管理器
      await EndpointManager.instance.addApiEndpoint(_apiBaseUrl!, priority: 0);
    }
    
    if (data.containsKey('jitsi_server_url')) {
      _jitsiServerUrl = data['jitsi_server_url'] as String;
      await prefs.setString(_keyJitsiServerUrl, _jitsiServerUrl!);
    }
    
    if (data.containsKey('socketio_url')) {
      _socketIoUrl = data['socketio_url'] as String;
      await prefs.setString(_keySocketIoUrl, _socketIoUrl!);
      // 同时添加到端点管理器
      await EndpointManager.instance.addSocketEndpoint(_socketIoUrl!, priority: 0);
    }
    
    if (data.containsKey('room_id')) {
      _roomId = data['room_id'] as String;
      await prefs.setString(_keyRoomId, _roomId!);
    }
  }
  
  /// 清除配置
  Future<void> clearConfig() async {
    final prefs = await SharedPreferences.getInstance();
    
    await prefs.remove(_keyApiBaseUrl);
    await prefs.remove(_keyJitsiServerUrl);
    await prefs.remove(_keySocketIoUrl);
    await prefs.remove(_keyRoomId);
    
    _apiBaseUrl = null;
    _jitsiServerUrl = null;
    _socketIoUrl = null;
    _roomId = null;
  }
}
