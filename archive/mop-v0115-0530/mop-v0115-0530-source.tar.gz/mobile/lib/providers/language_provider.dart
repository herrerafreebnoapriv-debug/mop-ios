import 'package:flutter/material.dart';

import '../core/services/storage_service.dart';

/// 语言状态管理
class LanguageProvider extends ChangeNotifier {
  Locale _currentLocale = const Locale('zh', 'CN');
  
  Locale get currentLocale => _currentLocale;
  
  LanguageProvider() {
    _loadLanguage();
  }
  
  /// 加载语言设置
  Future<void> _loadLanguage() async {
    final languageCode = await StorageService.instance.getLanguage();
    if (languageCode != null) {
      final parts = languageCode.split('_');
      if (parts.length == 2) {
        _currentLocale = Locale(parts[0], parts[1]);
        notifyListeners();
      }
    } else {
      // 使用系统默认语言
      // Flutter 会自动处理系统语言，这里先设置默认值
      _currentLocale = const Locale('zh', 'CN');
    }
  }
  
  /// 切换语言
  Future<void> changeLanguage(Locale locale) async {
    if (_currentLocale != locale) {
      _currentLocale = locale;
      final languageCode = '${locale.languageCode}_${locale.countryCode}';
      await StorageService.instance.saveLanguage(languageCode);
      notifyListeners();
    }
  }
  
  /// 支持的语言列表
  static const List<Locale> supportedLocales = [
    Locale('zh', 'CN'),  // 简体中文
    Locale('zh', 'TW'),  // 繁体中文
    Locale('en', 'US'),  // 英文
    Locale('ja', 'JP'),  // 日文
    Locale('ko', 'KR'),  // 韩文
  ];
}
