import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'core/services/storage_service.dart';
import 'providers/auth_provider.dart';
import 'providers/socket_provider.dart';
import 'screens/auth/login_screen.dart';
import 'screens/auth/register_screen.dart';
import 'screens/home/home_screen.dart';
import 'screens/qr/scan_screen.dart';
import 'screens/settings/settings_screen.dart';

/// 应用主组件
/// 根据用户登录状态显示不同页面
class AppMain extends StatefulWidget {
  const AppMain({super.key});

  @override
  State<AppMain> createState() => _AppMainState();
}

  @override
  void initState() {
    super.initState();
    _initializeApp();
  }

  /// 初始化应用
  Future<void> _initializeApp() async {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    final socketProvider = Provider.of<SocketProvider>(context, listen: false);
    
    // 等待 AuthProvider 加载登录状态
    // AuthProvider 在构造函数中会自动调用 _loadAuthStatus
    
    // 如果已登录，自动连接 Socket
    if (authProvider.isAuthenticated) {
      // 延迟一下，确保 AuthProvider 已完成初始化
      await Future.delayed(const Duration(milliseconds: 500));
      
      if (mounted && authProvider.isAuthenticated) {
        // 自动连接 Socket.io
        await socketProvider.autoConnect();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Consumer2<AuthProvider, SocketProvider>(
      builder: (context, authProvider, socketProvider, _) {
        // 如果已登录但 Socket 未连接，尝试连接
        if (authProvider.isAuthenticated && 
            authProvider.hasAgreedTerms && 
            !socketProvider.isConnected) {
          // 延迟连接，避免阻塞 UI
          WidgetsBinding.instance.addPostFrameCallback((_) {
            socketProvider.autoConnect();
          });
        }
        
        // 根据登录状态和免责声明同意状态显示不同页面
        if (authProvider.isAuthenticated && authProvider.hasAgreedTerms) {
          // 已登录且已同意免责声明，显示首页
          return const HomeScreen();
        } else {
          // 未登录或未同意免责声明，显示登录页
          return const LoginScreen();
        }
      },
    );
  }
}
