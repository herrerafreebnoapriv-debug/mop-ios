import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:provider/provider.dart';

import '../../core/config/app_config.dart';
import '../../locales/app_localizations.dart';
import '../../providers/auth_provider.dart';
import '../../services/qr/qr_scanner_service.dart';

/// 二维码扫描页面
class ScanScreen extends StatefulWidget {
  final String? publicKeyPem; // RSA 公钥（用于解密）
  final bool isForLogin; // 是否用于登录（扫码授权）
  
  const ScanScreen({
    super.key,
    this.publicKeyPem,
    this.isForLogin = false,
  });

  @override
  State<ScanScreen> createState() => _ScanScreenState();
}

class _ScanScreenState extends State<ScanScreen> {
  final QRScannerService _qrService = QRScannerService();
  MobileScannerController? _controller;
  bool _hasPermission = false;
  bool _isProcessing = false;
  String? _errorMessage;
  
  @override
  void initState() {
    super.initState();
    _initScanner();
  }
  
  Future<void> _initScanner() async {
    // 检查相机权限
    final hasPermission = await _qrService.checkCameraPermission();
    setState(() {
      _hasPermission = hasPermission;
    });
    
    if (hasPermission) {
      _controller = _qrService.createController();
      
      // 监听扫描结果
      _controller?.barcodes.listen((barcodes) {
        if (barcodes.isNotEmpty && !_isProcessing) {
          _handleScanResult(barcodes.first);
        }
      });
    }
  }
  
  Future<void> _handleScanResult(Barcode barcode) async {
    if (_isProcessing) return;
    
    setState(() {
      _isProcessing = true;
      _errorMessage = null;
    });
    
    try {
      // 处理扫描结果
      final data = await _qrService.processScanResult(
        barcode,
        publicKeyPem: widget.publicKeyPem,
      );
      
      if (mounted) {
        // 如果用于登录，使用扫码授权登录
        if (widget.isForLogin) {
          // TODO: 实现扫码授权登录
          // 这里需要调用后端 API 进行扫码授权
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('扫码授权功能待实现')),
          );
        } else {
          // 配置成功，返回上一页
          Navigator.of(context).pop(data);
        }
      }
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
        _isProcessing = false;
      });
      
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('扫描失败: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }
  
  @override
  void dispose() {
    _qrService.dispose();
    super.dispose();
  }
  
  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context);
    
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.isForLogin ? '扫码授权' : '扫描二维码'),
      ),
      body: _hasPermission
          ? Stack(
              children: [
                // 相机预览
                MobileScanner(
                  controller: _controller,
                  onDetect: (barcode) {
                    if (!_isProcessing && barcode.barcodes.isNotEmpty) {
                      _handleScanResult(barcode.barcodes.first);
                    }
                  },
                ),
                
                // 扫描框
                Center(
                  child: Container(
                    width: 250,
                    height: 250,
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: Colors.white,
                        width: 2,
                      ),
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                ),
                
                // 提示信息
                Positioned(
                  bottom: 100,
                  left: 0,
                  right: 0,
                  child: Center(
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 24,
                        vertical: 12,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.black54,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        '请将二维码对准扫描框',
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                        ),
                      ),
                    ),
                  ),
                ),
                
                // 错误信息
                if (_errorMessage != null)
                  Positioned(
                    top: 100,
                    left: 20,
                    right: 20,
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.red.withOpacity(0.9),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        _errorMessage!,
                        style: const TextStyle(color: Colors.white),
                      ),
                    ),
                  ),
                
                // 处理中提示
                if (_isProcessing)
                  const Center(
                    child: CircularProgressIndicator(),
                  ),
              ],
            )
          : Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(
                    Icons.camera_alt_outlined,
                    size: 64,
                    color: Colors.grey,
                  ),
                  const SizedBox(height: 16),
                  const Text('需要相机权限才能扫描二维码'),
                  const SizedBox(height: 24),
                  ElevatedButton(
                    onPressed: () async {
                      final hasPermission = await _qrService.checkCameraPermission();
                      setState(() {
                        _hasPermission = hasPermission;
                      });
                      
                      if (hasPermission) {
                        _initScanner();
                      }
                    },
                    child: const Text('授予权限'),
                  ),
                ],
              ),
            ),
    );
  }
}
