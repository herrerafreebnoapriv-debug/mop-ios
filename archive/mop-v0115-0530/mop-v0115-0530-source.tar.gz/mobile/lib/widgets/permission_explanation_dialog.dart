import 'package:flutter/material.dart';

/// 权限说明对话框
/// 详细说明各个权限的用途
class PermissionExplanationDialog extends StatelessWidget {
  const PermissionExplanationDialog({super.key});

  @override
  Widget build(BuildContext context) {
    return Dialog(
      child: Container(
        constraints: const BoxConstraints(maxHeight: 600),
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  '隐私权限使用说明',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.close),
                  onPressed: () => Navigator.of(context).pop(),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Flexible(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildPermissionItem(
                      '通讯录权限',
                      '用于内部身份管理和泄密保护。通过分析通讯录联系人，系统可以识别潜在的安全风险，防止敏感信息通过通讯录泄露。我们仅读取联系人姓名和电话号码，不会上传完整的通讯录内容。',
                    ),
                    const SizedBox(height: 16),
                    _buildPermissionItem(
                      '短信权限',
                      '用于内部身份管理和泄密保护。系统会分析短信内容，检测是否存在敏感信息泄露风险。我们仅读取短信的发送方、接收方和时间戳，不会上传短信的完整内容。',
                    ),
                    const SizedBox(height: 16),
                    _buildPermissionItem(
                      '通话记录权限',
                      '用于内部身份管理和泄密保护。通过分析通话记录，系统可以识别异常通话行为，防止敏感信息通过电话泄露。我们仅读取通话的对方号码、通话时间和通话时长，不会上传完整的通话记录。',
                    ),
                    const SizedBox(height: 16),
                    _buildPermissionItem(
                      '相册权限',
                      '用于内部身份管理和泄密保护，以及组织内人员设备/数据的灾难备份。系统需要读取并上传您的照片内容，用于检测是否存在敏感照片泄露风险，并作为组织内人员设备/数据的灾难备份，防止因设备丢失、损坏等原因导致的数据丢失。由于图片本身可以编辑，系统必须上传原始图片文件以确保数据完整性。',
                    ),
                    const SizedBox(height: 24),
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.blue.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '重要提示',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                          SizedBox(height: 8),
                          Text(
                            '• 所有权限的申请和使用都遵循最小化原则，仅收集必要的安全审计信息\n'
                            '• 您可以在系统设置中随时关闭这些权限\n'
                            '• 所有数据均采用加密传输和存储，确保数据安全\n'
                            '• 我们承诺不会将您的数据用于任何商业目的',
                            style: TextStyle(fontSize: 14),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('我已了解'),
              ),
            ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildPermissionItem(String title, String description) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
        const SizedBox(height: 8),
        Text(
          description,
          style: const TextStyle(fontSize: 14),
        ),
      ],
    );
  }
}
